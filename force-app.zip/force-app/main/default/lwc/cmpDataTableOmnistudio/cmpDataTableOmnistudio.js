import { LightningElement, api } from 'lwc';
import { OmniscriptBaseMixin } from 'vlocity_cmt/omniscriptBaseMixin';

// const columns = [
//     { label: 'Unidade Consumidora', fieldName: 'Name' },
//     { label: 'CNPJ', fieldName: 'CNPJ__c' }
// ]; 

export default class CmpDataTableOmnistudio extends OmniscriptBaseMixin(LightningElement) {
    selectedRows = [];
    @api recordId;

    connectedCallback() {
        this.template.addEventListener('selectrow', evt => {
            console.log('selectrow event', JSON.stringify(evt.detail.result));
            if(evt.detail.result.selectrow) {
                this.selectedRows.push(evt.detail.result);
            } else {
                this.selectedRows.forEach(function(item, index, object){
                    if(item.uniqueKey === evt.detail.result.uniqueKey) {
                        object.splice(index, 1);
                    }
                })
            }
            this.omniApplyCallResp({"selectedRows": this.selectedRows});
        });
	    const jsonData = JSON.parse(JSON.stringify(this.omniJsonData));
        this.tableData = jsonData.UCData;
    }
}